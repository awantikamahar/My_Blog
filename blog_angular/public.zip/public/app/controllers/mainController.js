angular.module('mainCtrl',[]).controller('mainController',function ($scope) {
	console.log('in maincontroller')
	
}) 